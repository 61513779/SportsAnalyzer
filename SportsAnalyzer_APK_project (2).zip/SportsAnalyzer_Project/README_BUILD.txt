SportsAnalyzer - Android prototype (Football only)

What's included:
- Minimal Android project (Kotlin) that calls football-data.org using Retrofit.
- The API key you provided is embedded in MainActivity for quick testing.
  (For production, move the key to a secure place; do NOT commit it to public repos.)

How to build the APK locally:
1. Install Android Studio (Arctic Fox or newer recommended).
2. Open the project located in the extracted folder as a Gradle project.
3. Let Gradle sync; it will download dependencies.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The generated APK will be under app/build/outputs/apk/debug/app-debug.apk

Notes:
- If you get API rate errors, ensure your football-data.org key is active.
- The code is a prototype. For production: handle errors, secure the API key, add tests, and implement caching.
