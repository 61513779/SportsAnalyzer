package com.example.sportsanalyzer

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.sportsanalyzer.databinding.ActivityMainBinding
import com.example.sportsanalyzer.models.MatchItem
import com.example.sportsanalyzer.network.ApiClient
import com.example.sportsanalyzer.network.FootballApi
import com.example.sportsanalyzer.ui.MatchAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.create

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val items = mutableListOf<MatchItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerViewMatches.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewMatches.adapter = MatchAdapter(items)

        // API key provided by you
        val apiKey = "a61db46ca5e545c8a073afd00ac28b65"

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val service = ApiClient.retrofit.create(FootballApi::class.java)
                val resp = service.getMatches(apiKey, "2025-10-01", "2025-10-04")
                for (m in resp.matches) {
                    items.add(
                        MatchItem(
                            id = m.id,
                            homeTeam = m.homeTeam.name,
                            awayTeam = m.awayTeam.name,
                            homeScore = m.score.fullTime.homeTeam,
                            awayScore = m.score.fullTime.awayTeam
                        )
                    )
                }
                runOnUiThread { binding.recyclerViewMatches.adapter?.notifyDataSetChanged() }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
