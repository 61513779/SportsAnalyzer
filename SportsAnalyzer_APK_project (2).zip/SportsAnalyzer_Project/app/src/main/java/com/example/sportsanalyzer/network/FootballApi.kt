package com.example.sportsanalyzer.network

import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query

interface FootballApi {
    @GET("matches")
    suspend fun getMatches(@Header("X-Auth-Token") apiKey: String,
                           @Query("dateFrom") from: String,
                           @Query("dateTo") to: String): MatchesResponse
}

data class MatchesResponse(val matches: List<MatchResponse>)
data class MatchResponse(
    val id: Long,
    val utcDate: String,
    val status: String,
    val homeTeam: TeamResponse,
    val awayTeam: TeamResponse,
    val score: ScoreResponse
)
data class TeamResponse(val id: Long, val name: String)
data class ScoreResponse(val fullTime: FullTimeScore)
data class FullTimeScore(val homeTeam: Int?, val awayTeam: Int?)
