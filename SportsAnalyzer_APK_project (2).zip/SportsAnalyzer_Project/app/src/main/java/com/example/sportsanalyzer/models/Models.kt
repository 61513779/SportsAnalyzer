package com.example.sportsanalyzer.models

data class MatchItem(
    val id: Long,
    val homeTeam: String,
    val awayTeam: String,
    val homeScore: Int?,
    val awayScore: Int?
)
