package com.example.sportsanalyzer.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.sportsanalyzer.R
import com.example.sportsanalyzer.models.MatchItem

class MatchAdapter(private val items: List<MatchItem>) : RecyclerView.Adapter<MatchAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvTeams: TextView = view.findViewById(R.id.tvTeams)
        val tvScore: TextView = view.findViewById(R.id.tvScore)
        val tvPrediction: TextView = view.findViewById(R.id.tvPrediction)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_match, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val m = items[position]
        holder.tvTeams.text = "${m.homeTeam} - ${m.awayTeam}"
        holder.tvScore.text = "${m.homeScore ?: "-"} - ${m.awayScore ?: "-"}"
        holder.tvPrediction.text = "Prédiction: ${simplePredict(m)}"
    }

    override fun getItemCount(): Int = items.size

    private fun simplePredict(m: MatchItem): String {
        val h = m.homeScore ?: -1
        val a = m.awayScore ?: -1
        if (h >= 0 && a >= 0) {
            return when {
                h > a -> "Victoire domicile"
                a > h -> "Victoire extérieur"
                else -> "Match nul"
            }
        }
        return when {
            m.id % 3L == 0L -> "Équipe domicile probable"
            m.id % 3L == 1L -> "Équipe extérieure probable"
            else -> "Match équilibré"
        }
    }
}
